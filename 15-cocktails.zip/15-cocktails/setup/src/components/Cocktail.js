import React from 'react'
import { Link } from 'react-router-dom'

const Cocktail = () => {
  return (
    <div>
      <h2>cocktail component</h2>
    </div>
  )
}

export default Cocktail
